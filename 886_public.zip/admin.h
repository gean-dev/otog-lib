bool usePakpim(int x);
int usePeteza();
int useBlackslex();
