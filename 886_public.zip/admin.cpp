#include <climits>
#include "admin.h"

bool usePakpim(int x) {
	return false;
}

int usePeteza() {
	return INT_MAX;
}

int useBlackslex() {
	return INT_MIN;
}
